/* sheets-api.js — ตัวเชื่อมระหว่างหน้าเว็บ ACC CRM กับ Google Sheet ผ่าน Apps Script Web App */
(() => {
  // 🔧 วาง URL ของ Web App ที่ deploy แล้วตรงนี้ (จบด้วย /exec)
  const API_URL = 'PASTE_YOUR_WEB_APP_URL_HERE';

  // 🔧 ต้องตรงกับ SECRET_TOKEN ใน Code.gs
  const TOKEN = 'CHANGE_ME_ACC_CRM_2569';

  function isConfigured() {
    return API_URL && API_URL.indexOf('https://script.google.com') === 0;
  }

  async function listSheet(sheetName) {
    if (!isConfigured()) throw new Error('ยังไม่ได้ตั้งค่า API_URL ใน sheets-api.js');
    const url = `${API_URL}?action=list&sheet=${encodeURIComponent(sheetName)}&token=${encodeURIComponent(TOKEN)}`;
    const res = await fetch(url);
    const json = await res.json();
    if (json.error) throw new Error(json.error);
    return json; // { sheet, headers, rows, startRow }
  }

  async function post(payload) {
    if (!isConfigured()) throw new Error('ยังไม่ได้ตั้งค่า API_URL ใน sheets-api.js');
    const res = await fetch(API_URL, {
      method: 'POST',
      body: JSON.stringify({ ...payload, token: TOKEN })
    });
    const json = await res.json();
    if (json.error) throw new Error(json.error);
    return json;
  }

  function updateCell(sheet, rowKey, col, value) {
    return post({ action: 'updateCell', sheet, rowKey, col, value });
  }

  function updateRow(sheet, rowKey, fields) {
    return post({ action: 'updateRow', sheet, rowKey, fields });
  }

  function addRow(sheet, rowKey, fields) {
    return post({ action: 'addRow', sheet, rowKey, fields });
  }

  function deleteRow(sheet, rowKey) {
    return post({ action: 'deleteRow', sheet, rowKey });
  }

  window.SheetsAPI = { isConfigured, listSheet, updateCell, updateRow, addRow, deleteRow };
})();
